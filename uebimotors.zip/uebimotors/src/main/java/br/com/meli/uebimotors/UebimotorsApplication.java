package br.com.meli.uebimotors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UebimotorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UebimotorsApplication.class, args);
	}

}
