package br.com.meli.uebimotors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UebimotorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
